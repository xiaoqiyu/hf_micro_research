#!/usr/bin/env python
# encoding: utf-8
'''
@author: yuxiaoqi
@contact: rpyxqi@gmail.com
@file: fee_calculation.py
@time: 2020/6/11 10:39
@desc:
'''

import numpy as np
import pandas as pd
from WindPy import w

w.start()


def nv_after_fee(nv_df, fee_rate=0.2, bm=None, thresh=0):
    '''
    根据业绩报酬前净值序列计算业绩报酬后的净值序列，考虑绝对计提
    :param nv_df: 业绩报酬前的净值序列，可为pd.Series或pd.DataFrame对象，index为日期
    :param fee_rate: 业绩报酬率，0.2表示20%，0.15表示15%，以此类推
    :param bm: benchmark，提取相对业绩报酬的对标指数，比如中证500指数，为pd.Series对象，index为日期
    :param thresh: 业绩报酬计提的水位，如8%表示年化8%计提
    :return: 业绩报酬后的净值序列
    '''
    if len(nv_df.shape) < 2:
        nv_df = nv_df.to_frame('after')
    nv_df.index.name = 'date'
    nv_df.columns.name = 'fund'
    df = nv_df.stack().to_frame('nv').sort_index(
        level=[1, 0]).reset_index()
    df['log_nv'] = df['nv'].pipe(np.log)
    if bm is None:
        df['log_bm'] = 0
    else:
        if len(bm.shape) > 1:
            bm = bm.iloc[:, 0]
        bm = bm.pipe(np.log).reindex(nv_df.index).ffill().bfill().to_frame(
            'log_bm')
        df = df.merge(bm, how='left', left_on='date', right_index=True)
    first_df = df.groupby('fund')[['date', 'log_nv', 'log_bm']].transform(
        'first')
    thresh_df = (np.log(1 + thresh) * (
            (df['date'] - first_df['date']) / pd.Timedelta(
        days=1))) / 365
    df['fee'] = (df['log_nv'] - first_df['log_nv']) - (
            df['log_bm'] - first_df['log_bm']) - thresh_df

    hwm = df.groupby(
        'fund', as_index=False, group_keys=False)['fee'].transform(
        lambda x: x.expanding().max().shift()).fillna(0).iloc[:, 0]
    df['fee'] = df['fee'] - hwm
    df['fee'] = df['fee'] * (df['fee'] > 0) * fee_rate
    df['rtn'] = df.groupby('fund')['log_nv'].apply(lambda x: x.diff()).fillna(
        df['log_nv'])
    df['nv_after'] = df['rtn'] - df['fee']
    df['nv_after'] = df.groupby('fund')['nv_after'].apply(
        lambda x: x.cumsum()).pipe(np.exp)
    return df.set_index(['date', 'fund'])['nv_after'].unstack()


def _get_bc_series(bc='', start_date='', end_date=''):
    '''
    bc: benchmark
    start_date: string
    end_date: string
    '''
    ret = w.wsd(bc, "close", start_date, end_date, "")
    return ret.Data[0], ret.Times


def calculate_fee():
    df = pd.read_csv('pre_fee.csv', encoding='gbk')
    df_bc = pd.read_csv('fee.csv', encoding='gbk')
    col_names = list(df.columns)
    col_names.remove("日期")
    _format_rate = lambda x: int(x.strip('%')) / 100
    df.index = pd.to_datetime(df["日期"], infer_datetime_format=True)
    bc_closes = dict()

    for col in col_names:
        if df_bc[col][1] != df_bc[col][1]:
            bc_closes.update({col: None})
        else:
            bc_mkt, ret_dates = _get_bc_series(df_bc[col][1], df["日期"][0], df["日期"][-1])
            bc_closes.update({col: pd.Series(bc_mkt, index=ret_dates)})

    ret_df = nv_after_fee(df[col_names[0]], fee_rate=_format_rate(df_bc[col_names[0]][0]),
                          bm=bc_closes.get(col_names[0]),
                          thresh=_format_rate(df_bc[col_names[0]][2]))
    ret_df.columns = [col_names[0]]
    for col in col_names[1:]:
        ret = nv_after_fee(df[col], fee_rate=_format_rate(df_bc[col][0]), bm=bc_closes.get(col),
                           thresh=_format_rate(df_bc[col][2]))
        ret.columns = [col]
        ret_df = ret_df.join(ret)
    ret_df.to_csv('after_fee.csv', encoding='gbk')


if __name__ == '__main__':
    calculate_fee()
